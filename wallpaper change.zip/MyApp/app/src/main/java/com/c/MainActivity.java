package com.c;

import android.app.*;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;

public class MainActivity extends Activity {

    private WallpaperManager wallpaperManager = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        wallpaperManager = WallpaperManager.getInstance(this);
    }

    public void changeWallpaper(View view) {

        try {
            switch (view.getId()) {
                case R.id.blue:
                    Bitmap blueImage = BitmapFactory.decodeResource(getResources(), R.drawable.blue);
                    wallpaperManager.setBitmap(blueImage);
                    Toast.makeText(this, "Blue", Toast.LENGTH_SHORT).show();
                    break;

                case R.id.green:
                    Bitmap greenImage = BitmapFactory.decodeResource(getResources(), R.drawable.green);
                    Bitmap greenScaled = Bitmap.createScaledBitmap(greenImage,
                            greenImage.getWidth()/2, greenImage.getHeight()/2, true);
                    wallpaperManager.setBitmap(greenScaled);
                    Toast.makeText(this, "Green", Toast.LENGTH_SHORT).show();
                    break;

                case R.id.orange:
                    Bitmap orangeImage = BitmapFactory.decodeResource(getResources(), R.drawable.orange);
                    Bitmap orangeScaled = Bitmap.createScaledBitmap(orangeImage,
                            orangeImage.getWidth()/3, orangeImage.getHeight()/3, true);
                    wallpaperManager.setBitmap(orangeScaled);
                    Toast.makeText(this, "Orange", Toast.LENGTH_SHORT).show();
                    break;

                case R.id.clear:
                    wallpaperManager.clear();
                    Toast.makeText(this, "Clear", Toast.LENGTH_SHORT).show();
                    break;
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
