package com.a;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;

public class edit extends Activity {

    private EditText nameInput;
    private EditText telInput;
    private EditText emailInput;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        prefs = getSharedPreferences("MY_DATA", MODE_PRIVATE);
        String name = prefs.getString("MY_NAME", "");
        int tel = prefs.getInt("MY_TEL", 0);
        String email = prefs.getString("MY_EMAIL", "");

        nameInput = (EditText)findViewById(R.id.nameInput);
        telInput = (EditText)findViewById(R.id.telInput);
        emailInput = (EditText)findViewById(R.id.emailInput);

        // Set default value.
        nameInput.setText(name);
        telInput.setText(tel+"");
        emailInput.setText(email);

    }

    public void saveData(View view) {
        // Get input text.
        String name = nameInput.getText().toString();
        int tel = Integer.parseInt(telInput.getText().toString());
        String email = emailInput.getText().toString();

        // Save data.
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("MY_NAME", name);
        editor.putInt("MY_TEL", tel);
        editor.putString("MY_EMAIL", email);
        editor.apply();

        // Return to main activity.
        startActivity(new Intent(getApplicationContext(), main.class));

    }
}
