package com.a;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;

public class main extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences prefs = getSharedPreferences("MY_DATA", MODE_PRIVATE);

        // getXXX(key, default value)
        String name = prefs.getString("MY_NAME", "no name");
        int tel = prefs.getInt("MY_TEL", 0);
        String email = prefs.getString("MY_EMAIL", "no email");

        // Set values
        ((TextView)findViewById(R.id.nameLabel)).setText(name);
        ((TextView)findViewById(R.id.telLabel)).setText(tel+"");
        ((TextView)findViewById(R.id.emailLabel)).setText(email);
    }

    public void showEdit(View view) {
        startActivity(new Intent(getApplicationContext(), edit.class));
  //  }
}


}
